package com.ryanprintup.starsector.net.packets;

import com.ryanprintup.starsector.net.Packet;

public class SpawnEntityPacket implements Packet
{
	// Todo

	@Override
	public byte getId()
	{
		return 29;
	}
}