package com.ryanprintup.starsector.net.packets;

import com.ryanprintup.starsector.net.Packet;

public class DamageTileGroupPacket implements Packet
{
	// Todo

	@Override
	public byte getId()
	{
		return 27;
	}
}